package com.world.erp.utils;

import android.content.Context;

import com.alipay.api.AlipayApiException;
import com.alipay.api.AlipayClient;
import com.alipay.api.DefaultAlipayClient;
import com.alipay.api.internal.util.AlipaySignature;
import com.alipay.api.request.AlipayTradePayRequest;
import com.alipay.api.response.AlipayTradePayResponse;
import com.world.erp.nohttp.CallServer;
import com.world.erp.nohttp.ResultListener;
import com.yolanda.nohttp.NoHttp;
import com.yolanda.nohttp.Request;
import com.yolanda.nohttp.RequestMethod;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by Administrator on 2017/3/20.
 */
public class HttpUtils {

    /**
     * 当前对象
     */
    private static HttpUtils httpUtils = null;

    /**
     * 短信请求头键
     */
    private static final String KEY = "ShopWebApiAuthorityCode";

    /**
     * 短信请求头值
     */
    private static final String VALUE = "601E5F61-1CDE-4DE9-ADD5-8E9065E5D578";

    /**
     * 短信请求头值
     */
    private static final String SMSVALUE = "601E5F61-1CDE-4DE9-ADD5-6666666666666666";

    /**
     * 微信公众号AppId
     */
    private static final String wxMpAppID = "wxb24254139c0c3ced";

    /**
     * 微信私钥
     */
    private static final String wxKey = "guangdonglangximaoyi891world8888";

    /**
     * 商户号
     */
    private static final String wxMchId = "1260934401";

    /**
     * 机器网络IP
     */
    private static final String wxSpbillCreateIp = "218.20.136.116";

    /**
     * 正式环境
     */
    private static final String http = "http://apiclient.891world.com/";

    /**
     * 构造方法
     */
    private HttpUtils() {
    }

    /**
     * @return 当前对象
     */
    public static HttpUtils getInstance() {
        if (httpUtils == null) {
            httpUtils = new HttpUtils();
        }
        return httpUtils;
    }

    /**
     * 请求体
     *
     * @param url 请求地址
     * @return 请求体
     */
    private Request<String> newRequest(String url) {
        return createRequest(url, "v");
    }

    /**
     * 请求体
     *
     * @param url 请求地址
     * @return 请求体
     */
    private Request<String> newSMSRequest(String url) {
        return createRequest(url, "SMS");
    }

    /**
     * 请求体
     *
     * @param url  请求地址
     * @param name 请求类型
     * @return 请求体
     */
    private Request<String> createRequest(String url, String name) {
        Request<String> request = NoHttp.createStringRequest(url, RequestMethod.POST);
        if ("SMS".equals(name)) {
            request.addHeader(KEY, SMSVALUE);
            request.addHeader("SourceFrom", "Android");
//            request.add("usercode", cs.USERCODE);
        } else {
            request.addHeader(KEY, VALUE);
        }
        return request;
    }

    /**
     * http 请求 可以取消进度条
     *
     * @param context  this
     * @param what     请求标识
     * @param request  请求体
     * @param listener 接口回调
     * @param hint     进度条提示
     */
    private void queue(Context context, int what, Request<String> request, ResultListener listener,
                       String hint) {
        CallServer.getRequestInstance().add(context, what, request, listener, true, hint);
    }

    /**
     * http 请求 不可以取消进度条
     *
     * @param context  this
     * @param what     请求标识
     * @param request  请求体
     * @param listener 接口回调
     * @param hint     进度条提示
     */
    private void noQueue(Context context, int what, Request<String> request, ResultListener listener,
                         String hint) {
        CallServer.getRequestInstance().add(context, what, request, listener, false, hint);
    }

    /**
     * 微信签名MD5
     *
     * @param auth_code    付款码
     * @param body         请求体
     * @param nonce_str    随机字符串
     * @param out_trade_no 订单号
     * @param total_fee    订单金额
     * @return 微信签名MD5
     */
    public String md5WxSign(String auth_code, String body, String nonce_str, String out_trade_no,
                            String total_fee) {
        String stringA = "appid=" + wxMpAppID + "&auth_code=" + auth_code + "&body=" + body +
                "&mch_id=" + wxMchId + "&nonce_str=" + nonce_str + "&out_trade_no=" + out_trade_no +
                "&spbill_create_ip=" + wxSpbillCreateIp + "&total_fee=" + total_fee + "&key=" + wxKey;
        return MD5Util.getMD5String(stringA).toUpperCase();
    }

    /**
     * 微信刷卡支付 body
     *
     * @param auth_code    付款码
     * @param body         请求体
     * @param nonce_str    随机码
     * @param out_trade_no 订单号
     * @param total_fee    订单金额
     * @param sign         微信签名MD5
     * @return 微信刷卡支付 body
     */
    private String createWxBody(String auth_code, String body, String nonce_str, String out_trade_no,
                                String total_fee, String sign) {
        return "<xml><appid>" + wxMpAppID + "</appid><auth_code>" + auth_code + "</auth_code><body>"
                + body + "</body><mch_id>" + wxMchId + "</mch_id><nonce_str>" + nonce_str +
                "</nonce_str><out_trade_no>" + out_trade_no + "</out_trade_no><spbill_create_ip>" +
                wxSpbillCreateIp + "</spbill_create_ip><total_fee>" + total_fee + "</total_fee><sign>"
                + sign + "</sign></xml>";
    }

    /**
     * 日期转换为订单号
     *
     * @return 格式:年月日时分秒毫秒 20170101010101999
     */
    public static String createOrder() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS");
        Date dt = new Date(System.currentTimeMillis());
        sdf.format(dt);
        return sdf.format(dt);
    }

    /**
     * 日期转换为订单号
     *
     * @return 格式:年月日时分秒毫秒 20170101010101999
     */
    public static String createOrderTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date dt = new Date(System.currentTimeMillis());
        sdf.format(dt);
        return sdf.format(dt);
    }

    //--------------------------------华丽的分割线--------------------------------

    /**
     * 用户登录
     *
     * @param userName 用户登录名
     * @param userPwd  用户密码
     * @param context  this
     * @param listener 请求回调
     */
    public void userLogin(String userName, String userPwd, Context context, ResultListener listener) {
        Request<String> request = newRequest(http + "Account/UserLogIn");
        request.add("userphone", userName);
        request.add("password", userPwd);
        queue(context, 10001, request, listener, "正在登录请稍后");
    }

    /**
     * 微信刷卡支付
     *
     * @param info     支付信息
     * @param context  this
     * @param listener 请求回调
     */
    public void createWxOrderPay(String info, Context context, ResultListener listener) {

        String[] wxInfo = info.split("&");
        String auth_code = wxInfo[0];
        String body = "POS收银刷卡支付";
        String nonce_str = System.currentTimeMillis() + "";
        String out_trade_no = createOrder();
        String total_fee = wxInfo[1];
        String sign = md5WxSign(auth_code, body, nonce_str, out_trade_no, total_fee);

        Request<String> request = newRequest("https://api.mch.weixin.qq.com/pay/micropay");
        request.add("appid", wxMpAppID);
        request.add("auth_code", auth_code);
        request.add("body", body);
        request.add("mch_id", wxMchId);
        request.add("nonce_str", nonce_str);
        request.add("out_trade_no", out_trade_no);
        request.add("spbill_create_ip", wxSpbillCreateIp);
        request.add("total_fee", total_fee);
        request.add("sign", sign);
        request.setRequestBody(createWxBody(auth_code, body, nonce_str, out_trade_no, total_fee, sign));
        noQueue(context, 20001, request, listener, "正在验证收款金额，请稍后...");
    }

    /**
     * 支付宝刷卡支付
     *
     * @param info     支付信息
     * @param context  this
     * @param listener 请求回调
     */
    public void createAlipayOrderPay(String info, Context context, ResultListener listener) {
        String[] alipayInfo = info.split("&");
//        String app_id = alipayAppId;//kongdexiang@livehigh.com.cn
        String auth_code = alipayInfo[0];
        String biz_content = biz();
        String body = "跨境电商";
        String charset = "UTF-8";
        String discountable_amount = "0.00";
        String method = "alipay.trade.pay";
        String out_trade_no = createOrder();
        String scene = "bar_code";
        String sign_type = "RSA";
        String subject = "易卖生活";
        String timestamp = createOrderTime();
        String total_amount = "0.01";
        String version = "1.0";

        StringBuilder sb = new StringBuilder();
        sb.append("app_id=" + alipayAppId);
        sb.append("&auth_code=" + auth_code);
        sb.append("&biz_content=" + biz_content);
        sb.append("&body=" + body);
        sb.append("&charset=" + charset);
        sb.append("&discountable_amount=" + discountable_amount);
        sb.append("&method=" + method);
        sb.append("&out_trade_no=" + out_trade_no);
        sb.append("&scene=" + scene);
        sb.append("&sign_type=" + sign_type);
        sb.append("&subject=" + subject);
        sb.append("&timestamp=" + timestamp);
        sb.append("&total_amount=" + total_amount);
        sb.append("&undiscountable_amount=" + total_amount);
        sb.append("&version=" + version);
        String sign = rsaAlipaySign(sb.toString(), charset, sign_type);

        Request<String> request = newRequest("https://openapi.alipay.com/gateway.do");
        request.add("app_id", alipayAppId);//
        request.add("auth_code", auth_code);    //支付授权码
        request.add("biz_content", biz_content);  //参照各产品快速接入文档
        request.add("body", body);  //参照各产品快速接入文档
        request.add("charset", charset); //
        request.add("discountable_amount", discountable_amount); //
        request.add("method", method);//
        request.add("out_trade_no", out_trade_no); //商户订单号
        request.add("scene", scene);//支付场景 条码支付，取值：bar_code 声波支付，取值：wave_code
        request.add("sign", sign);         //
        request.add("sign_type", sign_type);    //目前支持RSA2和RSA，推荐使用RSA2
        request.add("subject", subject);      //订单标题
        request.add("timestamp", timestamp);    //yyyy-MM-dd HH:mm:ss
        request.add("total_amount", total_amount); //订单金额 单位为元
        request.add("undiscountable_amount", total_amount); //订单金额 单位为元
        request.add("version", version);   //
        noQueue(context, 20002, request, listener, "正在验证收款金额，请稍后...");

    }

    public String rsaAlipaySign(String content, String charset, String sign_type) {
        try {
            return AlipaySignature.rsaSign(content, pk8, charset, sign_type);
        } catch (AlipayApiException e) {
            e.printStackTrace();
        }
        return "";
    }

    private String alipay_public_key = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDDI6d306Q8fIfCOaTXyiUeJHkrIvYISRcc73s3vF1ZT7XN8RNPwJxo8pWaJMmvyTn9N4HQ632qJBVHf8sxHi/fEsraprwCtzvzQETrNRwVxLO5jVmRGi60j8Ue1efIlzPXV9je9mkjzOmdssymZkh2QhUrCmZYI/FCEa3/cNMW0QIDAQAB";
    private String rsa_private_key = "MIICXAIBAAKBgQCgYc4bzTz85YKSFRcB6KN65Xr2GTwsdwA1ebeISxPUYN79GdkazG5j7p89earBWWlCeegI/zQHuTlXGMyrwW+H9617wPNccIp7M99EjBUTaZxhVOyNTGJiqHocspN4FSgZ6r87HDJSvJoGYIOFlYc5aYJiY+p2WbsHVQRKq6Ma+QIDAQABAoGANxiiZ6agFvj5XBnmp381+hgvn6+XnmbbKYPA6w9vpnwI3sYscSpdmfL1vXa4lGeU44NhlQWm6ChXbHZWiYKQP4g7Icgf4WciDrf1sFR2PVvZPKq9KecGj+Hy2OUiIzBBrilNPnt3vFst7R8N2t1GhE64W6gkkurG7w/Ni1P2RCECQQDMSmjrMJ95rzIzIFvKrXIvZ1Zfr2aGT3o+04Pm2iclovVZs2ZPjdzBlYEHpYnLB9MMYv3+g6pZx8JvqbpUhDkVAkEAyPo2eq9pz2gIjbcPZDQ8e2CWNDBi4Iohdw9VjLfs3nRDkx9YiEGsmFEWeL1OGh9SeUTXzZPKQY+Yaq4DDbdLVQJAQRI2hyuOsIjQeZ6F/nHu3BCTX5kUFBX+v0JKUl8Mdx2H/xF4tkBen77KQbBFysjsPZbOhqJTwZMyaLTsZ/1R3QJACZhwq3Dek2l7JxD7aiRYUuespDc/MUtHB8Eyq3JIm+JfK5IOjwrbq7YLZZ5cMUEXlfSkfQs2V+T8OPOv76K1tQJBALRIDI+sfomvLswVw0eHMG4EdxVH7XOkhxDoLS3qvGGZysVVBwSemTt3TXyD44AoPi86qB5CzRJT6AMUf40ppAY=";

    private String rsa_public_key = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCgYc4bzTz85YKSFRcB6KN65Xr2GTwsdwA1ebeISxPUYN79GdkazG5j7p89earBWWlCeegI/zQHuTlXGMyrwW+H9617wPNccIp7M99EjBUTaZxhVOyNTGJiqHocspN4FSgZ6r87HDJSvJoGYIOFlYc5aYJiY+p2WbsHVQRKq6Ma+QIDAQAB";
    private String pk8 = "MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAKBhzhvNPPzlgpIVFwHoo3rlevYZPCx3ADV5t4hLE9Rg3v0Z2RrMbmPunz15qsFZaUJ56Aj/NAe5OVcYzKvBb4f3rXvA81xwinsz30SMFRNpnGFU7I1MYmKoehyyk3gVKBnqvzscMlK8mgZgg4WVhzlpgmJj6nZZuwdVBEqroxr5AgMBAAECgYA3GKJnpqAW+PlcGeanfzX6GC+fr5eeZtspg8DrD2+mfAjexixxKl2Z8vW9driUZ5Tjg2GVBaboKFdsdlaJgpA/iDshyB/hZyIOt/WwVHY9W9k8qr0p5waP4fLY5SIjMEGuKU0+e3e8Wy3tHw3a3UaETrhbqCSS6sbvD82LU/ZEIQJBAMxKaOswn3mvMjMgW8qtci9nVl+vZoZPej7Tg+baJyWi9VmzZk+N3MGVgQelicsH0wxi/f6DqlnHwm+pulSEORUCQQDI+jZ6r2nPaAiNtw9kNDx7YJY0MGLgiiF3D1WMt+zedEOTH1iIQayYURZ4vU4aH1J5RNfNk8pBj5hqrgMNt0tVAkBBEjaHK46wiNB5noX+ce7cEJNfmRQUFf6/QkpSXwx3HYf/EXi2QF6fvspBsEXKyOw9ls6GolPBkzJotOxn/VHdAkAJmHCrcN6TaXsnEPtqJFhS56ykNz8xS0cHwTKrckib4l8rkg6PCturtgtlnlwxQReV9KR9CzZX5Pw486/vorW1AkEAtEgMj6x+ia8uzBXDR4cwbgR3FUftc6SHEOgtLeq8YZnKxVUHBJ6ZO3dNfIPjgCg+LzqoHkLNElPoAxR/jSmkBg==";
    private String alipayAppId = "2015073000192503";

    /**
     * 可以在服务端正常运行的收款方法
     *
     * @param auth_code 支付宝付款码
     */
    public void rsaAlipay(String auth_code, Context context, ResultListener listener) {
        try {
            System.out.print("开始");
            AlipayClient alipayClient = new DefaultAlipayClient(
                    "https://openapi.alipay.com/gateway.do",
                    alipayAppId,
                    pk8,
                    "json",
                    "UTF-8",
                    rsa_public_key,
                    "RSA"); //获得初始化的AlipayClient
            AlipayTradePayRequest request = new AlipayTradePayRequest(); //创建API对应的request类
            request.setBizContent("{" +
                    "    \"out_trade_no\":\"20150320010101002\"," +
                    "    \"scene\":\"bar_code\"," +
                    "    \"auth_code\":\"" + auth_code + "\"," +
                    "    \"subject\":\"易卖生活\"," +
                    "    \"store_id\":\"NJ_001\"," +
                    "    \"timeout_express\":\"2m\"," +
                    "    \"total_amount\":\"0.01\"" +
                    "  }"); //设置业务参数
            AlipayTradePayResponse response = null; //通过alipayClient调用API，获得对应的response类
            response = alipayClient.execute(request);

//            if (response.isSuccess()) {
//                System.out.println("调用成功");
//            } else {
//                System.out.println("调用失败");
//            }
        } catch (Exception e) {

            System.out.println("出错");
        }
// 根据response中的结果继续业务逻辑处理
    }

    private String biz() {
        return "<? xml version = \"1.0\" encoding=\"UTF-8\"?><alipay><response><biz_content>" + alipay_public_key + "</biz_content><success>true</success></response><sign>" + pk8 + "</sign><sign_type>RSA</sign_type></alipay>";
    }

    ///----------------------------------------------------------------------
    public void createWxOrderPays(String info, Context context, ResultListener listener) {

        Request<String> request = newRequest("http://BASE_URL/QR0001.do");
        request.add("version","");
        request.add("serialNo","");
        request.add("organNo","");
        request.add("merchNo","");
        request.add("transAmt","");
        request.add("commodityName","");
        request.add("orderType","");
        request.add("fee","");
        request.add("signature","");
    }
}
